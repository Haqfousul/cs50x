Video Demo: <https://youtu.be/pZXtx2Mj7IM>
Description: 
snack-game

Basic snack game in python using pygame 

install pygame in your system ="pip install pygame"

if this doesn't work the try this one = "py -m pip install -u pygame -- user" (or) "py -m pip install pygame"

Looking in to code:
   1.initialize pygame
   2.set up colours on diffrent roles in this game.
   3.Create the window that has to be displayed.
   4.Define the game title,testscreen the game plot
   5.Establish the game rules and methodalogitd

executing the ontire programe will pop up the game window !! okay than now its time to play